from .web_hazard_project import *

__doc__ = web_hazard_project.__doc__
if hasattr(web_hazard_project, "__all__"):
    __all__ = web_hazard_project.__all__